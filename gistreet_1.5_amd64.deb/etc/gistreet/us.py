import sys
import subprocess
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

class AutoSudoApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('giStreet')
        self.setGeometry(100, 100, 120, 50)

        layout = QVBoxLayout()

        label = QLabel('Contrasena')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('Arial', 10, QFont.Bold))
        layout.addWidget(label)

        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_input)

        button = QPushButton('Continuar')
        button.setStyleSheet("background-color: #4CAF50; color: white;")
        button.clicked.connect(self.execute_sudo_command)
        layout.addWidget(button)

        self.setLayout(layout)

    def execute_sudo_command(self):
        comando_a_ejecutar = "python3 /etc/gistreet/gistreet.py"
        contrasena_sudo = self.password_input.text()

        comando_sudo = f"echo '{contrasena_sudo}' | sudo -S -E {comando_a_ejecutar} &"

        subprocess.Popen(comando_sudo, shell=True)

        sys.exit()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    auto_sudo_app = AutoSudoApp()
    auto_sudo_app.show()
    sys.exit(app.exec_())
