import sys
import requests
import json
import os
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QComboBox, QTextEdit
from PyQt5.QtCore import Qt, QProcess

ACCESS_TOKEN = "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"
REPO_OWNER = "wismor"
REPO_NAME = "tienda-de-software"
ITEMS_PER_PAGE = 10

files = []

def fetch_files():
    response = requests.get(f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents", headers={"Authorization": f"token {ACCESS_TOKEN}"})
    files.extend([file["name"] for file in response.json() if file["name"].endswith(".deb")])

def install_selected_program():
    selected_index = program_combo.currentIndex()
    selected_file = files[selected_index]

    response = requests.get(f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{selected_file}", headers={"Authorization": f"token {ACCESS_TOKEN}"})
    download_url = response.json()["download_url"]

    downloaded_file = "/root/" + selected_file
    with open(downloaded_file, "wb") as file:
        file.write(requests.get(download_url).content)

    output_text.append("<span style='color: red;'>Instalando programa...</span>")
    output_text.repaint()

    process = QProcess()
    process.readyReadStandardOutput.connect(lambda: output_text.append(f"<span style='color: green;'>{str(process.readAllStandardOutput(), 'utf-8')}</span>"))
    process.readyReadStandardError.connect(lambda: output_text.append(f"<span style='color: red;'>{str(process.readAllStandardError(), 'utf-8')}</span>"))
    process.start("sudo", ["apt-get", "update"])
    process.waitForFinished()

    process.start("sudo", ["apt-get", "install", "-y", downloaded_file])
    process.waitForFinished()

    if process.exitCode() == 0:
        output_text.append("<span style='color: green;'>La instalación se realizó correctamente.</span>")
    else:
        output_text.append("<span style='color: red;'>La instalación falló. Por favor, revise el proceso. Detalles en /tmp/install_error.log</span>")

    # Eliminar el archivo descargado después de la instalación
    os.remove(downloaded_file)

def exit_program():
    sys.exit()

fetch_files()

app = QApplication(sys.argv)

window = QWidget()
window.setWindowTitle("Instalador de Programas Gistreet")
window.setGeometry(100, 100, 400, 400)

layout = QVBoxLayout()

program_label = QLabel("Seleccione un programa")
program_label.setAlignment(Qt.AlignCenter)
program_label.setStyleSheet("font-size: 16px; font-weight: bold;")
layout.addWidget(program_label)

program_layout = QHBoxLayout()
program_combo = QComboBox()
program_combo.addItems(files)
program_combo.setStyleSheet("font-size: 14px;")
program_layout.addWidget(program_combo)
layout.addLayout(program_layout)

output_text = QTextEdit()
output_text.setReadOnly(True)
output_text.setStyleSheet("background-color: #333; color: white; font-size: 14px;")
layout.addWidget(output_text)

install_button = QPushButton("Instalar Programa")
install_button.setStyleSheet("background-color: #4CAF50; color: white; font-size: 16px; padding: 5px 10px;")
install_button.clicked.connect(install_selected_program)
layout.addWidget(install_button)

exit_button = QPushButton("Salir")
exit_button.setStyleSheet("background-color: #FF0000; color: white; font-size: 16px; padding: 5px 10px;")
exit_button.clicked.connect(exit_program)
layout.addWidget(exit_button)

window.setLayout(layout)
window.show()

sys.exit(app.exec_())
